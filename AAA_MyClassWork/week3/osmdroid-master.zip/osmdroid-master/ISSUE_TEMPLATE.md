Please note: issues related to or caused by osmbonuspack will be closed with a
suggestion to open an issue at https://github.com/MKergall/osmbonuspack

(feel free to delete whatever doesn't apply)

## Issue Type

[ ] Question
[ ] Bug
[ ] Improvement
[ ] Build system related
[ ] Performance
[ ] Documentation


## Description and/or steps/code to reproduce the problem



## Environment

### If it's a bug, version(s) of android this affects:

All

### Version of osmdroid the issue relates to:

6.1.2

