/**
 * Samples related to plotting and working with the device's location
 */

package org.osmdroid.samplefragments.location;