package org.osmdroid.model;

/**
 * created on 1/1/2017.
 *
 * @author Alex O'Ree
 */

public interface IBaseActivity {
    String getActivityTitle();
}
